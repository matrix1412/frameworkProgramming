<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class frp extends Controller
{
    //
    public function home(){
        return view('home');
    }
    public function about(){
        return "Ini adalah halaman about";
    }
    public function contact(){
        return view('kontak');
    }
    public function produk(){
        return view('produk');
    }
}
