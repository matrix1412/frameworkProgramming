<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
    // return view('welcome');
// });

//Route::view('/','datang',['nama' => 'Institut Asia Malang']);

//Route::view('/','home');

//Route::get('/', [App\Http\Controllers\Frp::class, 'home']);
//Route::get('/about', [App\Http\Controllers\Frp::class, 'about']);
//Route::get('/contact', [App\Http\Controllers\Frp::class, 'contact']);

Route::get('/','frp@home');
Route::get('/about','Frp@about');
Route::get('/contact','Frp@contact');
//Route::get('/produk','Frp@produk');
 
Route::get('/produk', function () {
    return view('produk', [
        "nama" => "HARIS ABDUL AFIF",
        "email" => "abdulab9090@gmail.com"
    ]);
});

//Route::get('/about/{id?}', function ($id=null) {
//    return "Halaman ini menggunakan String : ".$id;
//});

//Route::redirect('/baru','/about'); 

//Route::view('/kontak','kontak');

